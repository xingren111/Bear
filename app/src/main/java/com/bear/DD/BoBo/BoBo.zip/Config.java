package com.bear.DD.BoBo;

public class Config {
    int maxbotnum;
    int maxDamagedOnce;
    int initialHP;
    int HPTodd;
    int initialLv;
    int restartHP;
}
