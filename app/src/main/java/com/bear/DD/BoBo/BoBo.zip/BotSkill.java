package com.bear.DD.BoBo;

import java.util.ArrayList;
import java.util.HashMap;

public class BotSkill {
    int id;
    int basicweight;
    ArrayList<ArrayList<Integer>> spcweight;
}
