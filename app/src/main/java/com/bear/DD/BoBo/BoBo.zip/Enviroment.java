package com.bear.DD.BoBo;

public enum Enviroment {
    BOT,HUMAN;
}
