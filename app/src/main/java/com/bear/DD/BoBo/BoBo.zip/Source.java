package com.bear.DD.BoBo;

public enum Source {
    T,A,C//塔/吸收/普通
}
